"""Ponto de entrada do bot Medellín (Pterodactyl: `python main.py`)."""

from medellin_bot.config import TOKEN
from medellin_bot.bot import bot

# Importar estes módulos registra os eventos e comandos slash no `bot`.
from medellin_bot import events, slash_commands  # noqa: F401


if not TOKEN:
    raise RuntimeError(
        "DISCORD_TOKEN não está configurado. Adicione o token do bot como um segredo "
        "com o nome DISCORD_TOKEN antes de iniciar."
    )


bot.run(TOKEN)
